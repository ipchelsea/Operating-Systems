public class Main {
    public static void main(String args[]){

        // Assume file is provided when program is called
        RoundRobin rr = new RoundRobin("pid.txt");
        rr.printSchedule();
        rr.calculateWait();
    }
}
