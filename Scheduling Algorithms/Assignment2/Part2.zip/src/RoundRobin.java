import java.util.*;
import java.io.*;

class RoundRobin{

	static final int QUANTUM = 3; // size of quantum. can be changed to any positive int
	
    private class Process{
        int id;
        int startTime;
        int burstAmt;
        int burstTime;
        int finishTime;

        public Process(int id, int start, int burst){
            this.id = id;
            startTime = start;
            burstAmt = burst; // used for algorithm
            burstTime = burst; // used for calculations
            finishTime = 0;
        }
        
        
        // simple getters and setters
        public int getStartTime(){
            return startTime;
        }
        
        public int getFinishTime() {
        	return finishTime;
        }
        
        public int getBurstTime() {
        	return burstTime;
        }
        
        public int getPID() {
        	return id;
        }
        
        public void setFinishTime(int finishTime) {
        	this.finishTime = finishTime;
        }

        // return value is leftover cycles from QUANTUM
        // if return value is <0 process still has time left
        // if return value is 0 process is finished within QUANTUM
        // if return value is >0 process is finished with left over QUANTUM time
        public int simulate(int QUANTUM, ArrayList<Integer> timeChart){
            burstAmt -= QUANTUM;
            //add ourselves to the timeChart for the amount of QUANTUM used
            for (int i = 0; i < QUANTUM + Math.min(0, burstAmt); i++){
                timeChart.add(id);
            }
            return -burstAmt;
        }

    } // end of class Process

    
    // arraylist for storing processes for scheduling algorithm
    private ArrayList<Process> processes = new ArrayList<>();
   
    // array for storing finished processes for calculating info
    private Process[] finishedProcesses;
    
    
    // reads in from file that is passed from main
    // creates all processes and loads them into an arraylist
    // assumes the processes are in arrival order
    public RoundRobin(String file){
        try{
            Scanner in = new Scanner(new File(file));

            // makes scanner stop at every white space
            in.useDelimiter("\\s");

            while (in.hasNext()){
                in.next(); // skip first part
                if(!in.hasNextInt()){
                    break;
                }
                Process process = new Process(processes.size() + 1, in.nextInt(), in.nextInt());
                processes.add(process);
                in.next();
            }
            
            // initialize array for storing finished processes
            finishedProcesses = new Process[processes.size() + 1];
            in.close();

        } catch (Exception e){
            e.printStackTrace();
        }
    }


    public void printSchedule(){

        ArrayList<Integer> timeChart = new ArrayList<>();

        int processTurn = 0;
        while (processes.size() > 0){
        	//totalTurn++;
            //if we are at the beginning of the process list and that
            //process is not yet running, add -1 to the time chart
            //(skipping that ms) until that process needs to run
            while (processes.get(processTurn).getStartTime() > timeChart.size()){
                //add -1 to time chart, also note we are at processTurn 0
                timeChart.add(-1);
            }


            //run next process up to given QUANTUM
            int cyclesLeft = processes.get(processTurn).simulate(QUANTUM, timeChart);
            if (cyclesLeft >= 0){
                //process finished, remove from processList
                //we do not need to increment the turn because the next item
                //on the list is in the same spot
            	
            	// store the current turn as the finishTime
            	processes.get(processTurn).setFinishTime(timeChart.size() - 1);
            	
            	// add finished process to array
            	finishedProcesses[processes.get(processTurn).getPID()] = processes.get(processTurn);
                processes.remove(processTurn);
                
            } else if(processes.size() > processTurn + 1 &&
                    processes.get(processTurn + 1).getStartTime() <= timeChart.size()){
                processTurn++;
                
            } else{
                //further processes not yet running, go back to beginning
                processTurn = 0;
                
            }
            if(processes.size() == 0){
                break;
            }
            processTurn %= processes.size(); //loop back to beginning
        }

        // prints the time Chart horizontally
        for (int i = 0; i < timeChart.size(); i++){
            System.out.print("" + i + "\t");
        }
        System.out.println();
        for (int pid : timeChart){
            if(pid == -1){
                System.out.print("X\t");
            } else {
                System.out.print("P" + pid + "\t");
            }
        }
        System.out.println();
    }
    
    // calculates the wait time and tat for each process and the avg of each
    public void calculateWait() {
    	int totalWait = 0;
    	int totalTAT = 0;
    	
    	// iterate through the array printing the individual process info
    	// while adding up the total wait and TAT
    	for (int i = 1; i < finishedProcesses.length; i++) {
    		int finishedTime = finishedProcesses[i].getFinishTime();
    		int tat = finishedTime - finishedProcesses[i].getStartTime();
    		
    		int wait = finishedProcesses[i].getFinishTime() - finishedProcesses[i].getBurstTime() 
    				- finishedProcesses[i].getStartTime() + 1;
    		
    		// prints the info on the processes
    		System.out.println("P" + i + ":" );
    		System.out.println("\tStart: " + finishedProcesses[i].getStartTime());
    		System.out.println("\tEnd: " + finishedTime);
    		System.out.println("\tBurst: " + finishedProcesses[i].getBurstTime());
    		System.out.println("\tWait: " + wait);
    		System.out.println("\tTAT:  " + tat);
    		
    		// add to totals
    		totalWait += wait;
    		totalTAT += tat;
    	}
    	
    	// needs -1 because PID is index and there is no PID = 0
    	double avgWait = totalWait / (finishedProcesses.length - 1);
    	double avgTAT = totalTAT / (finishedProcesses.length - 1);
    	System.out.println();
    	
    	System.out.println("avg wait: " +  avgWait);
    	System.out.println("avg TAT:  " + avgTAT);
    }
}