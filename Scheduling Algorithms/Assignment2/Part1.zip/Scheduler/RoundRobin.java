import java.util.*;
import java.io.*;

class RoundRobin{

    private class Process{
        int id;
        int startTime;
        int burstAmt;
        int finishTime;

        public Process(int id, int start, int burst){
            this.id = id;
            startTime = start;
            burstAmt = burst;
            finishTime = -1;
        }
        
        
        public int getStartTime(){
            return startTime;
        }
        
        public int getFinishTime() {
        	return finishTime;
        }
        
        public int getBurstTime() {
        	return burstAmt;
        }
        
        public int getPID() {
        	return id;
        }
        
        public void setFinishTime(int finishTime) {
        	this.finishTime = finishTime;
        }

        // return value is leftover cycles from quantum
        // if return value is <0 process still has time left
        // if return value is 0 process is finished within quantum
        // if return value is >0 process is finished with left over quantum time
        public int simulate(int quantum, ArrayList<Integer> timeChart){
            burstAmt -= quantum;
            //add ourselves to the timeChart for the amount of quantum used
            for (int i = 0; i < quantum + Math.min(0, burstAmt); i++){
                timeChart.add(id);
            }
            return -burstAmt;
        }

    }

    ArrayList<Process> processes = new ArrayList<>();
    Process[] finishedProcesses;
    int quantum = 3;

    public RoundRobin(String file){
        try{
            Scanner in = new Scanner(new File(file));

            // makes scanner stop at every white space
            in.useDelimiter("\\s");

            while (in.hasNext()){
                in.next(); // skip first part
                if(!in.hasNextInt()){
                    break;
                }
                Process process = new Process(processes.size() + 1, in.nextInt(), in.nextInt());
                processes.add(process);
                in.next();
            }
            finishedProcesses = new Process[processes.size() + 1];
            in.close();

        } catch (Exception e){
            e.printStackTrace();
        }
    }


    public void printSchedule(){

        ArrayList<Integer> timeChart = new ArrayList<>();

        int processTurn = 0;
        int totalTurn = 0;
        while (processes.size() > 0){
        	//totalTurn++;
            //if we are at the beginning of the process list and that
            //process is not yet running, add -1 to the time chart
            //(skipping that ms) until that process needs to run
            while (processes.get(processTurn).getStartTime() > timeChart.size()){
                //add -1 to time chart, also note we are at processTurn 0
                timeChart.add(-1);
                totalTurn++;
                
            }


            //run next process up to given quantum
            int cyclesLeft = processes.get(processTurn).simulate(quantum, timeChart);
            if (cyclesLeft >= 0){
                //process finished, remove from processList
                //we do not need to increment the turn because the next item
                //on the list is in the same spot
            	processes.get(processTurn).setFinishTime(timeChart.size() - 1);
            	finishedProcesses[processes.get(processTurn).getPID()] = processes.get(processTurn);
                processes.remove(processTurn);
                
            } else if(processes.size() > processTurn + 1 &&
                    processes.get(processTurn + 1).getStartTime() <= timeChart.size()){
                processTurn++;
               // totalTurn++;
                
            } else{
                //further processes not yet running, go back to beginning
                processTurn = 0;
               totalTurn++;
                
            }
            if(processes.size() == 0){
                break;
            }
            processTurn %= processes.size(); //loop back to beginning
            totalTurn += 3;
        }

        for (int i = 0; i < timeChart.size(); i++){
            System.out.print("" + i + "\t");
        }
        System.out.println();
        for (int pid : timeChart){
            if(pid == -1){
                System.out.print("X\t");
            } else {
                System.out.print("P" + pid + "\t");
            }
        }
        System.out.println();
    }
    
    public void calculateWait() {
    	int totalWait = 0;
    	for (int i = 1; i < finishedProcesses.length; i++) {
    		System.out.println("P" + i + ": " + finishedProcesses[i].getFinishTime());
    		totalWait += (finishedProcesses[i].getFinishTime() - finishedProcesses[i].getBurstTime() - finishedProcesses[i].getStartTime());
    	}
    	
    	double avgWait = totalWait / finishedProcesses.length;
    	System.out.println("avg wait: " +  avgWait);
    	
    }
}