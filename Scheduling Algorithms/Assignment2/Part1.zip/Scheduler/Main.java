public class Main {
    public static void main(String args[]){

        // Assume file is provided when program is called

        ShortestJobFirst sjf = new ShortestJobFirst("test1.txt");
        sjf.schedule();

        RoundRobin rr = new RoundRobin("test1.txt");
        rr.printSchedule();

    }
}
