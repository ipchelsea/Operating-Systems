/*
It is important to note that if there is not a \r\n at the last line in the test text file, there is a line of code at ~38 that needs to be commented
This will also not work if there is an empty line at the bottom of the test text file.
If a new job comes in with a runtime equal to that of another job, it follows FCFS order.


Group: Dana Chinn, Yvana Higgins, Chelsea Ip, James Pfleger, Jordan Lawson
Scheduler Part 1: SJF with preemption
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class ShortestJobFirst {
    private String fileName;
    private ArrayList<Tuple> exeOrder = new ArrayList<Tuple>();
    private ArrayList<Process>  completedJobs = new ArrayList<Process>();

    public ShortestJobFirst(String fn){
        fileName = fn;
    }

    public void schedule() {
        try {
            File f = new File(fileName);
            Scanner sc = new Scanner(f);

            // get out the different processes
            //use a linked list because it'll remove elements from the front
            LinkedList<Process> input = new LinkedList<Process>();
            while((sc.hasNextLine())){
                String pid = sc.next();
                String startTime = sc.next();
                String cpuBurst = sc.next();
                Process temp = new Process(pid, startTime, cpuBurst);
                input.add(temp);
                sc.nextLine(); // needed if there is a carriage return on the last line of input from the .txt file
            }

            LinkedList<Process> waiting = new LinkedList<Process>();

            int time = 0;
            int runtime = 0;
            Process active = null;
            // the logic here is a little hard to follow, there's a long explanation of the loops and ifs at the bottom of the file.
            // basically, it either changes active, changes the queues, or runs time and/or runs jobs per loop
            while(!input.isEmpty() || !waiting.isEmpty() || active != null) {
                //get all jobs that have come in, and add them to wait
                while (!input.isEmpty() && input.get(0).getStart() <= time) {
                    // examine just the front of the list
                    //insert in sorted order to the wait queue
                    insertionSort(waiting, input.get(0));
                    input.removeFirst();
                }

                // check if active is currently not set to anything
                if (active == null) {
                    if (!waiting.isEmpty()) {
                        active = waiting.getFirst();
                        waiting.removeFirst();
                        runtime = 0;
                    }
                    // if the wait queue is empty, you need to wait for more jobs to come in
                    else{
                        time++;
                        System.out.println("Time: " + time + " PID Running: NONE");
                    }
                }
                //check if front of waitlist has higher priority than active OR if the active process has finished.
                // if it does, swap the current process for it.
                // log the swap in exeorder
                // add the active back into the waitlist

                else if ((!waiting.isEmpty()) && (active.getTimeRemaining() > waiting.get(0).getTimeRemaining() || active.isComplete())) {
                    Tuple temp = new Tuple(runtime, active);
                    Process tmp = active;
                    active = waiting.get(0);
                    runtime = 0;
                    waiting.removeFirst();
                    // check if more is needed to be done on the current process.
                    if (!tmp.isComplete()) {
                        insertionSort(waiting, tmp);
                    }
                    else{
                        //tracks completed jobs for easy data perusal.
                        completedJobs.add(tmp);
                    }
                    exeOrder.add(temp);

                }
                else if(active.isComplete()){
                    completedJobs.add(active);
                    exeOrder.add(new Tuple(runtime, active));
                    runtime = 0;
                    active = null;
                }
                else {
                    runtime++;
                    time++;
                    active.runProcess(1, time);
                    System.out.println("Time: " + time + " PID Running: " + active.getPid());
                }

            }

            // print everything
            printExeOrder();
            printStats();

        } catch (FileNotFoundException e){
            e.printStackTrace();
        }

    }

    // prints avg. wait and avg. TAT
    public void printStats(){
        double totalWait = 0.0;
        int totalJobs = 0;
        double totalTAT = 0.0;
        for(Process i : completedJobs){
            totalJobs++;
            totalWait+=i.getWait();
            totalTAT+=i.calcTat();
        }
        System.out.println("Average TAT: " + totalTAT/totalJobs);
        System.out.println("Average Wait: " + totalWait/totalJobs);

    }

    //prints execution order with quantums
    public void printExeOrder(){
        for(Tuple i : exeOrder){
            i.printTuple();
        }
    }

    // insert in sorted order with insertionSort.
    // if runtime is equivalent, it will insert behind.
    private void insertionSort(LinkedList<Process> wait, Process temp){
        boolean inserted = false;
        for(int i = 0; i < wait.size(); i++) {
            if (wait.get(i).getTimeRemaining() > temp.getTimeRemaining()) {
                wait.add(i, temp);
                inserted = true;
                break;
            }
        }
            //add to last element
            if(inserted == false){
                wait.add(temp);
            }
    }

}

//the logic here is a little wonky to follow. Time does not increase per loop always.
// map of the while and if's
            /*
            While(There are still more jobs coming in, there are still jobs to do that are queued, or there is still an active running process)
                // this next while loop handles getting in incoming jobs to be queued into Ready
                While(input isn't empty, and the first job in input has arrived)
                    add the first job to the ready queue (waiting) in sorted order
                    remove it from the input list

                if (the active job isn't set to anything)
                    if (waiting has jobs queue'd)
                        set active to the first job in the queue
                    else
                        increase time, because there's still jobs incoming, but nothing to do right now

                else if waiting is empty, and, you need to swap jobs because of priority or the active job has finished
                    store the activity active had in exeOrder
                    if active was complete, log it in completedJobs
                    if active was incomplete, store it in the ready queue in sorted order
                    set active to the front of the wait queue
                    reset runtime

                else if (active is finished (but the wait queue is empty!))
                    add active to the completed jobs list, add the activity to exeOrder
                    reset active to null (there is no current job, but there's still one in the future)
                    reset runtime

                else:
                    run the job
                    increment the runtime
                    increment time
                    make all the ready processes wait

             */
