public class Process {
    private String pid;
    private int start;
    private int cpu;
    private int timeRemaining;
    private int complete = -1;


    public Process(String process, String queueTime, String cpuTime) {
        pid = process;
        start = Integer.parseInt(queueTime);
        cpu = Integer.parseInt(cpuTime);
        timeRemaining = cpu;


    }
    private Process(String process, int queueTime, int cpuTime, int tRemain, int completed){
        pid = process;
        start = queueTime;
        cpu = (cpuTime);
        timeRemaining = tRemain;

        complete = completed;
    }


    public void runProcess(int quantum, int time) {
        timeRemaining -= quantum;
        if(timeRemaining <= 0 && complete <= 0){
            complete = time;
        }
    }

    public String getPid() {
        return pid;
    }

    public int getCpu() {
        return cpu;
    }

    public int getTimeRemaining(){
        return timeRemaining;
    }

    public int getStart(){
        return start;
    }


    public void print(){
        System.out.println("pid: " + pid + "\nQ Time: " + start + "\ntimeRemaining: " + timeRemaining);
    }

    public int calcTat(){
        return this.getWait() + cpu;
    }

    public int getWait(){
        return complete - (start + cpu);
    }

    public boolean isComplete(){
        if (timeRemaining <= 0){
            return true;
        }
        return false;
    }

    public Process deepCopy(){
        Process temp = new Process(pid, start, cpu, timeRemaining, complete);
        return temp;
    }
}
