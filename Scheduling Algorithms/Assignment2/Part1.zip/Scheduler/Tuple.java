public class Tuple{
    public int quantum;
    public Process pid;

    public Tuple(int quant, Process process){
        quantum = quant;
        pid = process;
    }

    public String get_name(){
        return pid.getPid();
    }
    public int getRunTime(){
        return pid.getTimeRemaining();
    }

    public void print(){
        System.out.println("quantum: " + quantum);
        pid.print();
    }
    public void printTuple(){
        System.out.println("PID: " + pid.getPid() + " runs for " + quantum+  " units of time");
    }


}
