import java.util.*;
import java.io.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
      RoundRobin rr = new RoundRobin("file3.txt");
      rr.RoundRobinScheduling();
    }

}
