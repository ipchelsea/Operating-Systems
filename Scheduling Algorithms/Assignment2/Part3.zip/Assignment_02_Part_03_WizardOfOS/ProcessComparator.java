import java.util.Comparator;

//Finds the highest priority number by using a comparator function.
//Comparator tells the process how to compare the objects
public class ProcessComparator implements Comparator<Process> {
    @Override
    public int compare(Process x, Process y) {
        if (x.getPriority() < y.getPriority())
        {
            return -1;
        }
        if (x.getPriority() > y.getPriority()) {
            return 1;
        }
        return 0;
    }
}
