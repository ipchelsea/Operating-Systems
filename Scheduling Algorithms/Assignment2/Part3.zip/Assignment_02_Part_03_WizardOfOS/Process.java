
//////////////////////////      PROCESS CLASS       ///////////////////////////
///////////////////////////////////////////////////////////////////////////////
public class Process
{
    private String id;
    private double TAT, waitTime;
    private int arrivalTime, burstTime, tempBurstTime, priority, finishTime;

    //Process constructor
    public Process(String id, int AT, int BT, int priority)
    {
        this.id = id;
        this.arrivalTime = AT;
        this.burstTime = BT;
        this.tempBurstTime = BT;
        this.priority = priority;
    }

    public String getId() {
        return id;
    }

    public int getAT() {
        return arrivalTime;
    }

    public double getWaitTime(){
        return waitTime;
    }

    public double getTAT() {
        return TAT;
    }

    public int getBT() {
        return burstTime;
    }

    public double getWT() {
        return waitTime;
    }

    public int getTempBT() {
        return tempBurstTime;
    }

    public int getPriority() {
        return priority;
    }

    public int getFinishTime() {
        return finishTime;
    }

    public void setWaitTime(double WT) {
        this.waitTime = WT;
    }

    public void setTAT(double TAT) {
        this.TAT = TAT;
    }

    public void setTempBT(int BT) {
        this.tempBurstTime = BT;
    }

    public void setFinishTime(int time) {
        this.finishTime = time;
    }

    public void printProcess() {
        System.out.println("-Process ID: " +  this.getId());
        System.out.println("-Process Arrival Time: "+ this.getAT());
        System.out.println("-Process Burst Time " + this.getBT());
        System.out.println("-Temporary Burst Time: " + this.getTempBT());
        System.out.println("-Priority: " + this.getPriority());
    }
}
