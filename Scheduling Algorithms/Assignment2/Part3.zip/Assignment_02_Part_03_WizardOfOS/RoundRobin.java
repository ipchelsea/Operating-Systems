import java.util.*;
import java.io.*;
import java.util.PriorityQueue;

class RoundRobin
{

  private int quantum = 3;
  public void setQuantum( int qt){
    quantum = qt;
  }

  ArrayList<Process> processList = new ArrayList<>(); //to get process id's
  ArrayList<Process> processToRun = new ArrayList<>();

  ////////////////////        CONSTRUCTOR RoundRobin     /////////////////////
  ////////////////////////////////////////////////////////////////////////////
  public RoundRobin(String file){
      try{
          Scanner in = new Scanner(new File(file));
          // makes scanner stop at every white space
          while (in.hasNext()){
              //ID, AT, BT & priority
              Process process = new Process(in.next(), in.nextInt(), in.nextInt(), in.nextInt());
              processList.add(process);
              processToRun.add(process);
          }
          in.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    /////////////////////////////////////////////////////////////////////////////
    public void findWTAvg()
    {
      double avgWT = 0;
      for(int i = 0; i < processList.size(); i++)
      {
       avgWT += (processList.get(i)).getWT();
      }
      avgWT = avgWT/(double)(processList.size());
      System.out.println("Average Wait Time: " + avgWT);
    }

    ////////////////////////////////////////////////////////////////////////////////
    public void findTATAvg()
    {
      double avgTAT = 0;
      for(int i = 0; i < processList.size(); i++)
      {
       avgTAT += (processList.get(i)).getTAT();
      }
      avgTAT = avgTAT/(processList.size());
      System.out.println("Average Turn Around Time: " + avgTAT);
    }

    ////////////////////////////////////////////////////////////////////////////////
    //TAT: Basically Burst Time + Wait Time
    public void findWTandTAT()
    {
       for(int i = 0; i < processList.size(); i++)
       {
         Process tempProcess = (processList.get(i));
         tempProcess.setWaitTime(tempProcess.getFinishTime() - tempProcess.getAT() - tempProcess.getBT());
         tempProcess.setTAT(tempProcess.getWaitTime() + tempProcess.getAT());
         System.out.println("Process: " + tempProcess.getId() + " Wait Time: " + tempProcess.getWT() + " Turn Around Time: " + tempProcess.getTAT());
       }
    }

    ////////////////////////////////////////////////////////////////////////////
    public void RoundRobinScheduling() {
        Scanner scn = new Scanner(System.in);
        System.out.println("If you would like to change the quantum from 3 ms, type the new number");
        System.out.println("Else type 0 to keep it 3 ms");
        int  newQuantum = scn.nextInt();

        if(newQuantum > 0)
        {
          quantum = newQuantum;
        }

        Comparator<Process> comparator = new ProcessComparator();
        PriorityQueue<Process> priorityQueue = new PriorityQueue<>(10, comparator);

        int timeFrame = 0;

        Process nextProcess = priorityQueue.poll();

        Process firstProcess = processList.get(0);
        for(int i = 1; i < processList.size(); i++)
        {
            if(processList.get(i).getAT() < processList.get(i-1).getAT())
            {
                firstProcess = processList.get(i);
            }
        }

        priorityQueue.add(firstProcess);
        int startOfQuantum = 0;
        int runTimeQuantum = quantum;
        while(!(processToRun.isEmpty()))
        {

          if(!(priorityQueue.isEmpty()))
          {
            System.out.println(" ");
            System.out.println( "Current Number of Elements in the Q: " + priorityQueue.size());
                //check for processes that arrived and add appropriate processes to the
                //priority queue.
            Process runningProcess = priorityQueue.poll();

            if (runningProcess.getTempBT() <= quantum)
            {
              runTimeQuantum = runningProcess.getTempBT();
              timeFrame = timeFrame + runningProcess.getTempBT();
              runningProcess.setTempBT(0);
              runningProcess.setFinishTime(timeFrame);
              processToRun.remove(runningProcess);

              System.out.println("The current timeFrame is: " + timeFrame);
              // dequeue process from priorityQ forever
            }
            else
            {
              runningProcess.setTempBT(runningProcess.getTempBT() - quantum);//doesn't work yet
              priorityQueue.add(runningProcess);
              timeFrame += quantum;
              System.out.println("The current timeFrame is: " + timeFrame);
            }

            runningProcess.printProcess();

            for(int i = 0; i < processToRun.size(); i++)
            {
                if((processToRun.get(i)).getAT() <= timeFrame && (processToRun.get(i)).getAT() > startOfQuantum )
                {
                  priorityQueue.add(processToRun.get(i));
                }
            }

            startOfQuantum += runTimeQuantum;
          }
          System.out.println(" ");
        }

        findWTandTAT();
        findWTAvg();
        findTATAvg();
    }
}
