/*
    Class: Main
    Final Project: Linux File System
    Team: Wizard of OS (James Pfleger, Yvana Higgens, Chelsea Ip, Jordan Lawson, Dana Chinn)
    Summer 2019

    Main: reads commands from the specified file one line at a time and performs them.
        outputs all log entries to Log.txt
     */

import java.io.*;
import java.util.Scanner;

class Main {

    public static void main(String[] args)
    {
        try
        {
            PrintWriter out = new PrintWriter("Log.txt");
            fileReader("command.txt", out);

            // Leave this at the very end of main!
            out.close();
        }
        catch(FileNotFoundException e){ }

    }

    // fileReader method to parse commands from file
    public static void fileReader(String file, PrintWriter out) {
        try{
            Scanner in = new Scanner(new File(file));
            // makes scanner stop at every white space
            FileSys fs = new FileSys();
            int fileLine = 1;
            while (in.hasNext()){
                out.println("File Line: " + fileLine);
                String command = in.next();
                //System.out.println(command);
                if(command.equals("FM"))
                {
                    out.println("Initializing file system via command FM");
                    fs = new FileSys();
                    fs.assignLog(out);
                    fileLine++;
                    out.println();
                    continue;
                }

                String fileName = in.next();
                //System.out.println("File Name = " + fileName);
                if(command.equals("DF"))
                {
                    out.println("Deleting " + fileName + " via command DF");
                    fs.deleteFile(fileName);
                    fileLine++;
                    out.println();
                    continue;
                }
                int blocks = in.nextInt();
                //System.out.println(blocks);
                if(command.equals("NF"))
                {
                    out.println("Creating " + fileName + " with block size " + blocks + " via command NF");
                    fs.createFile(fileName, blocks);
                }
                if(command.equals("MF"))
                {
                    out.println("Adding " + blocks + " block(s) to " + fileName + " via command MF");
                    fs.addBlocks(fileName, blocks);
                }
                if(command.equals("DB"))
                {
                    out.println("Deleting " + blocks + " block(s) from " + fileName + " via command DB");
                    fs.deleteBlocks(fileName, blocks);
                }
                out.println();
                fileLine++;
            }

            // prints the bitmap on the disk and all the inodes to the log
            fs.printDisk();
            fs.printInode();
            in.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }


}
